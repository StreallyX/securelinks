<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page de Profil</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<link href="https://fonts.googleapis.com/css?family=Roboto|Work+Sans:400,600" rel="stylesheet">
    <header class="header">
            <nav role="navigation">
            <h1 id="NavTitle">SecureLinks</h1>
            <div id="menuToggle">
              <input type="checkbox" />
                <span></span>
                <span></span>
                <span></span>
            <ul id="menu">
              <li><a href="../index.php">Home</a></li>
              <li><a href="tarifs.php">Pricing</a></li>
              <li><a href="example.php">Example</a></li>
              <li><a href="contact.php">Contact</a></li>
            </ul>
           </div>
          </nav>
        
    </header>
    <div class="content">
        <div class="tarifs-container">
            <div class="tarif">
                <h2>Get a free website template</h2>
                <p class="price">Free</p>
                <p>Choose from a selection of free website templates.</p>
                <a href="create2.php" class="tarif-button">Create</a>
            </div>
            <div class="tarif">
                <h2>Create your website</h2>
                <p class="price">1499€</p>
                <p>Get a fully secured website tailored to your needs.</p>
                <a href="contact.php" class="tarif-button">Contact</a>
            </div>
        </div>
    </div>
    <footer class="footer">
        <div class="contact-info">
            <h3>Contact Us</h3>
            <p>Email: securelinkspro@gmail.com</p>
            <p>Phone: +41 76 675 77 23</p>
        </div>
        <div class="social-media">
            <h3>Follow Us</h3>
            <ul>
                <li><a href="#"><img src="facebook-icon.png" alt="Facebook"></a></li>
                <li><a href="#"><img src="twitter-icon.png" alt="Twitter"></a></li>
                <li><a href="#"><img src="linkedin-icon.png" alt="LinkedIn"></a></li>
            </ul>
        </div>
    </footer>
</body>
</html>