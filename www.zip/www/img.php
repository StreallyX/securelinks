<form action="upload.php" method="post" enctype="multipart/form-data">
  Sélectionnez une image à charger :
  <input type="file" name="fileToUpload" id="fileToUpload">
  <input type="submit" value="Charger Image" name="submit">
</form>
