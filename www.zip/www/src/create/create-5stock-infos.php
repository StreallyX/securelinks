<?php

    // Stockage DB
    session_start();
    var_dump($_SESSION); 
    header('Location: create-6validation.php');
 ?>