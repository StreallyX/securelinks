<?php
    if($_GET['data'] === "1"){
        //https://mym.fans/Anawhiterose
        echo "yes";
        header("Location: ../create.php");
    }
    else if($_GET['data'] === "2"){
        //https://onlyfans.com/ana.whiterose
        echo "yes1";
        header("Location: ../contact.php");
    }
?>